<?php 
    $db = mysqli_connect('localhost','root','','basic');
    if($db == false){
        echo 'Error';

    }
?>